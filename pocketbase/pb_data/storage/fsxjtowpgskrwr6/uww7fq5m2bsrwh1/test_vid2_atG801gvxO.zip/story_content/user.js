function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6kDOaLtkTVi":
        Script1();
        break;
  }
}

function Script1()
{
  window.addEventListener('message',function(e){
    if (e.origin == 'https://all-truth.com') {
        var SLplayer = GetPlayer();
        
        if (e.data == 'ended'){ 
            SLplayer.SetVar("VimeoVideoEnded", false);
            SLplayer.SetVar("VimeoVideoEnded", true);
            
        } else if (e.data == "loaded") {
            var iframe = document.querySelector('iframe');
            
            var videoWatched = SLplayer.GetVar("VimeoVideoEnded");
            var message = videoWatched ? "true" : "false";
            iframe.contentWindow.postMessage(message, "https://all-truth.com");
        }
    }
});
}

